/* 
HWJava18_09_Chap12Summary_배재연.zip

연습문제

Q5. 다음은 클래스와 인터페이스 간의 상속 문법이다.
	 extends, implements, 불가능 중 적절한 상속 키워드를 넣으시오.

클래스 __________ 클래스 {	// extends
	// ...
}

인터페이스 __________ 인터페이스 {	// extends
	// ...
}

클래스 __________ 인터페이스 {	// implements
	// ...
}

인터페이스 __________ 클래스 {	// 불가능
	// ...
}
 */

package classes;

public class Chap12_ExerciseQ5 {
	public static void main(String[] args) {
	}
}
