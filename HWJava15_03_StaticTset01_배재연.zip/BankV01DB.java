/*
HWJava15_03_StaticTset01_배재연.zip
*/

package classes;

class BankV01DB {
	String[][] bankInfo = new String[][] 	{
																{"BANK001","오민환"}, {"BANK002","남궁준"},
																{"BANK003","박창원"}, {"BANK004","김광준"},
																{"BANK005","백광덕"}, {"BANK006","윤주섭"},
																{"BANK007","최준호"}};
			
	int[] vBalance = {35000, 4000, 3000, 2500, 45000, 3000, 5000};
}