/*
HWJava15_03_StaticTset01_배재연.zip
*/

package classes;

class BankV01Main {
	public static void main(String[] args) {
		BankV01DAO obj = new BankV01DAO();
		obj.dtoSet();
		obj.printBankInfo();
	}
}