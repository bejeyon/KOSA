package classes;

class UsageOfDataType
{
	public static void main(String[] args) 
	{
		// 변수 선언과 함께 값 대입
		int a = 3;
		// 변수 선언과 값 대입 분리
		int b;
		b = 4;
		System.out.println(a);
		System.out.println(b);
	}
}
