/*
HWJava10_12_Chap05_ExerciseQ1Q7_배재연.zip

ExerciseQ1.

배열의 2가지 특징을 기술하시오.

배열은 동일한 자료형을 묶어 저장하는 참조 자료형으로,
1. 생성할 때 크기를 지정해야 한다.
2. 한 번 크기를 지정하면 절대 변경할 수 없다.
는 2가지 특징이 있다.
*/
package classes;

class Chap05_ExerciseQ1
{
	public static void main(String[] args) 
	{

	}
}