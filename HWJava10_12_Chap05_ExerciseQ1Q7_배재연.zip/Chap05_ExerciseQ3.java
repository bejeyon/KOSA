/*
HWJava10_12_Chap05_ExerciseQ1Q7_배재연.zip

ExerciseQ3.

다음 코드의 출력 결과를 쓰시오.

double[] a = {1.2, 3.4, 5.6};
double[] b = a;
b[0] = 7.8;
System.out.println(Arrays.toString(a));
System.out.println(Arrays.toString(a));

1.2
3.4
5.6
7.8
3.4
5.6
*/
package classes;

class Chap05_ExerciseQ3
{
	public static void main(String[] args) 
	{

	}
}