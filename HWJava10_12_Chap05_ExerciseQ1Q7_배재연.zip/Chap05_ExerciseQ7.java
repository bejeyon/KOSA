/*
HWJava10_12_Chap05_ExerciseQ1Q7_배재연.zip

ExerciseQ7.

다음의 코드의 실행 결과를 쓰시오.

String a = "방가";
String b = new String("방가");
String c = "방가";
String d = new String("방가");
String e = "방가";
String f = new String("방가");

System.out.println(a == b);
System.out.println(a == c);
System.out.println(a == d);
System.out.println(a == e);
System.out.println(a == f);
System.out.println();

System.out.println(b == c);
System.out.println(b == d);
System.out.println(b == e);
System.out.println(b == f);

=========================

false
true
false
true
false

false
false
false
false
*/
package classes;

class Chap05_ExerciseQ7
{
	public static void main(String[] args) 
	{
		
	}
}