/*
HWJava14_09_Chap09Summary01_배재연.zip
*/

// 같은 패키지에서 클래스 접근 지정자와 생성자 접근 지정자

package classes.pack0;

// public class
public class CC {
	CC() {	// default 기본생성자 직접 생성
	}
}
