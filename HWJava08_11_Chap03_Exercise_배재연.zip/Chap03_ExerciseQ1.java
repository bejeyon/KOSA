/*
HWJava08_11_Chap03_Exercise_배재연.zip

Q1. 다음은 산술 연산에 관한 코드다. 출력값을 쓰시오.

System.out.println(2 + 3 / 2);			// 3
System.out.println(10 % 3 + 5 / 3);	// 2
System.out.println((4 + 5 / 2) % 4);	// 2
*/
package classes;

class Chap03_ExerciseQ1
{
	public static void main(String[] args) 
	{
		System.out.println(2 + 3 / 2);			// 3
		System.out.println(10 % 3 + 5 / 3);	// 2
		System.out.println((4 + 5 / 2) % 4);	// 2
	}
}