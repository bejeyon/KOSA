/*
HWJava08_11_Chap03_Exercise_배재연.zip

Q6. 다음은 논리 연산자에 관한 코드다. 출력값을 쓰시오.

System.out.println(false && true);			// false
System.out.println((4 <= 4) || (6 < 3));	// true
System.out.println(false ^ (3 >= 4));		// false
System.out.println(!(3 <= 3));					// false
*/
package classes;

class Chap03_ExerciseQ6
{
	public static void main(String[] args) 
	{
		System.out.println(false && true);			// false
		System.out.println((4 <= 4) || (6 < 3));	// true
		System.out.println(false ^ (3 >= 4));		// false
		System.out.println(!(3 <= 3));					// false
	}
}