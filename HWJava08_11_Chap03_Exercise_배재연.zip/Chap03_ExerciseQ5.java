/*
HWJava08_11_Chap03_Exercise_배재연.zip

Q5. 다음은 비교 연산자에 관한 코드다. 출력값을 쓰시오.

System.out.println(3 < 3);		// false
System.out.println(5 >= 3);	// true
System.out.println(5 <= 5);		// true
System.out.println(5 == 5);	// true
System.out.println(5 != 5);		// false
*/
package classes;

class Chap03_ExerciseQ5
{
	public static void main(String[] args) 
	{
		System.out.println(3 < 3);		// false
		System.out.println(5 >= 3);	// true
		System.out.println(5 <= 5);		// true
		System.out.println(5 == 5);	// true
		System.out.println(5 != 5);		// false
	}
}