package classes;

class TravelV01DB {
	String[][] travelInfo = {{"TRAV001", "뮌헨", "핀란드항공"},
										{"TRAV002", "프라하", "에어프랑스"},
										{"TRAV003", "오사카", "대한항공"},
										{"TRAV004", "상해", "아시아나항공"},
										{"TRAV005", "마닐라", "필리핀항공"}};
	int[] travelType = {0, 1, 1, 0, 1};
	int[] maxPerson = {15, 20, 12, 22, 17};
}