/*
8장 연습문제
Q1. 패키지를 사용하는 2가지 이유를 쓰시오.

1. 연관성 있는 class들을 모아놓아 관리에 용이함.
2. 패키지의 영향으로 클래스가 저장되는 공간이 분리돼 클래스명의 충돌을 방지할 수 있음.
*/

package classes;

public class Chap08_ExerciseQ1 {
	public static void main(String[] args) {

	}
}
