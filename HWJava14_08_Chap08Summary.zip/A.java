package classes.common;

public class A {
	public int m = 3;
	public int n = 4;

	public void print() {
		System.out.println("임포트");
	}

	public static void main(String[] args) {
	}
}
