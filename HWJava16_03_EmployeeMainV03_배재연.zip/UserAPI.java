package classes;

class UserAPI
{
	void mLine(String ch1, int num){
		for(int i = 1 ; i <= num ; i++)
			System.out.print(ch1);
	}

	public static void main(String[] args) 
	{
		
	}
}