/*
HWJava15_02_Chap09Summary02_배재연.zip
9장 연습문제

Q2. 클래스 자체에 사용할 수 있는 접근 지정자를 접근 범위가 큰 순서대로 쓰시오.

public > default
*/

package classes;

class Chap9_ExerciseQ2 {
	public static void main(String[] args) {
		
	}
}
