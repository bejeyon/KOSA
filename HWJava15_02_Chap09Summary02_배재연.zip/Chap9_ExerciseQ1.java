/*
HWJava15_02_Chap09Summary02_배재연.zip
9장 연습문제

Q1. 클래스 내부에 올 수 있는 4가지 구성 요소(필드, 메서드, 생성자, 이너 클래스)에서 사용할 수 있는 접근 지정자를 접근 범위가 큰 순서대로 쓰시오.

public > protected > default > private
*/

package classes;

class Chap9_ExerciseQ1 {
	public static void main(String[] args) {
		
	}
}
