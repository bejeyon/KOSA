/*
HWJava16_08_Chap10_Exercise_배재연.zip

10장 연습문제

Q1. 생성자의 2가지 문법적 조건은 무엇인가?

1. class명과 이름이 같다.
2. 리턴 타입이 없다.
*/

package classes;

class Chap10_ExerciseQ1 {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}
