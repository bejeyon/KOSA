/*
11장 연습문제

Q4. 다음은 추상 메서드 하나를 포함하고 있는 추상 클래스 A를 정의한 것이다.
	문법적으로 틀린 부분을 모두 찾아 수정하시오.

class A {	// abstract class 선언 필요
	void abc();	// abstract 지정자 필요
}
*/

package classes;

abstract class A {
	abstract void abc();
}

public class Chap11_ExerciseQ4 {
	public static void main(String[] args) {

	}
}
